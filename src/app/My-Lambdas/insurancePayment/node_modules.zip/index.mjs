import { Pool } from 'pg';
import Stripe from 'stripe';
import { readFileSync } from 'fs';

const pool = new Pool({
  host: process.env.DB_HOST,
  port: 5432,
  user: process.env.DB_USERS,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  ssl: {
    rejectUnauthorized: true,
    ca: readFileSync('/opt/lambda-layer/nodejs/eu-central-1-bundle.pem').toString(),
  },
});

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: '2022-11-15' });

export async function handler(event) {
  try {
    const { email, insuranceBuying } = JSON.parse(event.body);

    const client = await pool.connect();
    try {
      // Buscar usuario por email
      const userRes = await client.query(
        'SELECT id, nombre, email, seguro FROM users WHERE email = $1 LIMIT 1',
        [email]
      );

      if (userRes.rowCount === 0) {
        return { statusCode: 404, body: JSON.stringify({ error: 'usuario no encontrado' }) };
      }

      const user = userRes.rows[0];

      // Si ya tiene seguro, retornarlo
      if (user.seguro) {
        return {
          statusCode: 200,
          body: JSON.stringify({ message: 'usuario ya tiene seguro', seguro: user.seguro }),
        };
      }

      // Buscar el seguro que quiere comprar
      const seguroRes = await client.query(
        'SELECT id, nombre, descripcion, precio_cents, moneda FROM seguros WHERE id = $1 LIMIT 1',
        [insuranceBuying]
      );

      if (seguroRes.rowCount === 0) {
        return { statusCode: 400, body: JSON.stringify({ error: 'insuranceBuying inválido' }) };
      }

      const selectedSeguro = seguroRes.rows[0];

      // Crear sesión Stripe
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        mode: 'payment',
        line_items: [
          {
            price_data: {
              currency: selectedSeguro.moneda || 'usd',
              product_data: {
                name: selectedSeguro.nombre,
                description: selectedSeguro.descripcion || undefined,
                metadata: { seguro_id: selectedSeguro.id.toString() },
              },
              unit_amount: Number(selectedSeguro.precio_cents),
            },
            quantity: 1,
          },
        ],
        customer_email: email,
        success_url: `${process.env.STRIPE_SUCCESS_URL}?session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: process.env.STRIPE_CANCEL_URL || process.env.STRIPE_SUCCESS_URL,
        metadata: {
          user_id: user.id.toString(),
          user_email: email,
          seguro_id: selectedSeguro.id.toString(),
        },
      });

      return {
        statusCode: 200,
        body: JSON.stringify({
          message: 'checkout session creada',
          sessionId: session.id,
          url: session.url,
          seguro: selectedSeguro,
        }),
      };
    } finally {
      client.release();
    }
  } catch (err) {
    console.error('handler error:', err);
    return { statusCode: 500, body: JSON.stringify({ error: 'error interno del servidor' }) };
  }
}
