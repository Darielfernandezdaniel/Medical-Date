import sgMail from '@sendgrid/mail';

sgMail.setApiKey(process.env.SENDGRID_API_KEY);

async function enviarEmail(to, subject, text) {
    const msg = {
      to,                   // destinatario
      from: 'darieltwitter46@gmail.com', // debe coincidir con tu sender identity
      subject,
      text,
    };
  
    try {
      await sgMail.send(msg);
      console.log("✅ Email enviado a", to);
    } catch (error) {
      console.error("❌ Error enviando email:", error);
    }
  }

  export const handler = async (event, context) => {
    context.callbackWaitsForEmptyEventLoop = false;
  
    try {
      const { email, nombreCompleto } = JSON.parse(event.body);
  
      await enviarEmail(
        email,
        'Solicitud de Contacto',
        `Hola ${nombreCompleto},\nhemos recibido tu ticket, lo procesaremos cuanto antes`
      );
  
      return {
        statusCode: 200,
        headers: { "Access-Control-Allow-Origin": "*" },
        body: JSON.stringify({ message: 'Email enviado correctamente' })
      };
  
    } catch (error) {
      console.error("❌ Error en Lambda:", error);
      return {
        statusCode: 500,
        headers: { "Access-Control-Allow-Origin": "*" },
        body: JSON.stringify({ error: error.message })
      };
    }
  };