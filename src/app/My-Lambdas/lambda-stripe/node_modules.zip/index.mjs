import Stripe from "stripe";
import pkg from "pg";
const { Pool } = pkg;

// Inicializa Stripe
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// Configura la conexión a PostgreSQL
const pool = new Pool({
  host: process.env.RDS_HOST,
  port: process.env.RDS_PORT || 5432,
  user: process.env.RDS_USER,
  password: process.env.RDS_PASSWORD,
  database: process.env.RDS_DBNAME,
  ssl: { rejectUnauthorized: false } // si usas SSL
});

export const handler = async (event) => {
  let client;

  try {
    const sig = event.headers['stripe-signature'];
    const payload = event.body;
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

    // Verifica el webhook de Stripe
    let stripeEvent;
    try {
      stripeEvent = stripe.webhooks.constructEvent(payload, sig, webhookSecret);
    } catch (err) {
      console.error("Webhook inválido:", err);
      return { statusCode: 400, body: "Webhook inválido" };
    }

    if (stripeEvent.type === 'checkout.session.completed') {
      const session = stripeEvent.data.object;

      // Metadata que define el tipo de pago
      const tipoPago = session.metadata.tipo; // "seguro" o "cita_medica"
      const nombreSeguro = session.metadata.nombre_seguro; // nombre del seguro

      if (tipoPago === "seguro") {
        // Conectar a PostgreSQL
        client = await pool.connect();

        const query = `
          INSERT INTO patients (seguro)
          VALUES ($1)
        `;
        await client.query(query, [nombreSeguro]);

        console.log("Pago de seguro registrado:", nombreSeguro);
      } else {
        console.log("Pago no es seguro, no se escribe en la tabla");
      }
    }

    return { statusCode: 200, body: "OK" };

  } catch (err) {
    console.error("Error procesando webhook:", err);
    return { statusCode: 500, body: "Error interno" };
  } finally {
    if (client) client.release();
  }
};
