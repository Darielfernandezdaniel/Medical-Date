import Stripe from 'stripe';
import { Buffer } from 'buffer';
import pkg from 'pg';
const { Client } = pkg;

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
client = new Client({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  port: 5432,
  ssl: {
    rejectUnauthorized: true,
    ca: readFileSync('/opt/lambda-layer/nodejs/eu-central-1-bundle.pem').toString()
  }
})

export const handler = async (event) => {
  const rawBody = event.isBase64Encoded
    ? Buffer.from(event.body, 'base64').toString()
    : event.body;

  const sigHeader =
    event.headers['Stripe-Signature'] ||
    event.headers['stripe-signature'];

  try {
    const stripeEvent = stripe.webhooks.constructEvent(
      rawBody,
      sigHeader,
      process.env.STRIPE_ENDPOINT_SECRET
    );

    // Maneja el evento según su tipo
    switch (stripeEvent.type) {
      case 'payment_intent.succeeded':
        // 👉 Lógica para manejar el pago exitoso
        console.log('✅ Pago exitoso:', stripeEvent.data.object.id);
        break;

      case 'payment_intent.payment_failed':
        // 👉 Lógica para manejar el pago fallido
        console.log('❌ Pago fallido:', stripeEvent.data.object.id);

        // Puedes acceder al motivo del fallo
        const paymentIntent = stripeEvent.data.object;
        console.log('Motivo de error:', paymentIntent.last_payment_error?.message);
        break;

      // Agrega más casos según los eventos que desees manejar
      default:
        console.log(`Evento no manejado: ${stripeEvent.type}`);
    }

    return {
      statusCode: 200,
      body: JSON.stringify({ received: true }),
    };
  } catch (err) {
    console.error('Error al verificar el webhook:', err);
    return {
      statusCode: 400,
      body: `Webhook Error: ${err.message}`,
    };
  }
};
